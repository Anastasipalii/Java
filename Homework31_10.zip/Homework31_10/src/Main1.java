public class Main1 {
    public static void main(String[] args) {
String str = "I study Basic Java!";
char lastChar = str.charAt(str.length() -1);
        System.out.println("The last char of a line: " + lastChar);
        System.out.println(str.contains("Java"));
        System.out.println(str.replace("o", "a"));
        System.out.println(str.toLowerCase());
        System.out.println(str.toUpperCase());
        int startIndex = str.indexOf("Java");
        if (startIndex != -1){
            String modifiedString = str.substring(0, startIndex) + "Java".length();
            System.out.println("Stroka posle udalenia podstroki 'Java': " + modifiedString);
        }else {
            System.out.println("Podstroka 'Java' ne naydena v stroke.");
        }

    }
}
