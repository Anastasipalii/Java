import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("pervoe slovo: ");
        String word1 = scanner.next();
        System.out.println("vtoroe slovo: ");
        String word2 = scanner.next();
        if (word1.length() % 2 == 0 && word2.length() % 2 == 0) {
            StringBuilder result = new StringBuilder();
            for (int i = 0; i < word1.length() / 2; i++) {
                result.append(word1.charAt(i));
            }
            for (int i = word2.length() / 2; i < word2.length() ; i++) {
                result.append(word2.charAt(i));
            }
            System.out.println("Result: " + result.toString());
        }else {
            System.out.println("Oba slova dolschni soderchat chetnoe kolichestvo bukv.");
        }

    }
}