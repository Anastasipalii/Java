import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String[] day_of_week = {"MONDAY" , "TUESDAY" , "WEDNESDAY" , "THURSDAY" ,
        "FRIDAY" , "SATURDAY" , "SUNDAY"};
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the current day of the week: ");
        String currentDay = scanner.nextLine();
        boolean dayFound = false;
        for (String day : day_of_week) {
            if (day.equalsIgnoreCase(currentDay)) {
                dayFound = true;
                continue;
            }
            System.out.println(day);
        }
        if (!dayFound) {
            System.out.println("Incorrect day of the week. ");
        }
    }
}