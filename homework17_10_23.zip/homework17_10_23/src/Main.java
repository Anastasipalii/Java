import wedding_anniversary.Wedding_Anniversary;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of years married: ");
        int yearsInMarriage = scanner.nextInt();
        int anniversaryYear = yearsInMarriage +1;
        Wedding_Anniversary wedding_anniversary;
        wedding_anniversary = switch (anniversaryYear) {
            case 1 -> Wedding_Anniversary.GREEN_WEDDING;
            case 2 -> Wedding_Anniversary.PAPER_WEDDING;
            case 3 -> Wedding_Anniversary.LEATHER_WEDDING;
            case 4 -> Wedding_Anniversary.LINEN_WEDDING;
            case 5 -> Wedding_Anniversary.WOODEN_WEDDING;
            case 6 -> Wedding_Anniversary.COPPER_WEDDING;
            case 7 -> Wedding_Anniversary.TIN_WEDDING;
            case 8 -> Wedding_Anniversary.CHAMOMILE_WEDDING;
            case 9 -> Wedding_Anniversary.STEEL_WEDDING;
            case 10 -> Wedding_Anniversary.LACE_WEDDING;
            case 11 -> Wedding_Anniversary.AGATE_WEDDING;
            case 12 -> Wedding_Anniversary.CRYSTAL_WEDDING;
            case 13 -> Wedding_Anniversary.TOPAZ_WEDDING;
            case 14 -> Wedding_Anniversary.PINK_WEDDING;
            case 15 -> Wedding_Anniversary.TURQUOISE_WEDDING;
            default -> throw new RuntimeException("Uncorrect Name");
        };

        String Wedding_Anniversary;
        System.out.println("Next wedding anniversary: " + wedding_anniversary);
    }
}