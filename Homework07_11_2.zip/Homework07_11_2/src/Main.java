import car.Cars;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Cars car1 = new Cars("BMW", "X6" , 2022, 1.9, true);
        Cars car2 = new Cars("TOYOTA", "Corolla" , 2021, 1.8, false);
        Cars car3 = new Cars("AUDI", "A7" , 2023, 1.6, true);
        System.out.println(car1);
        System.out.println(car2);
        System.out.println(car3);
        Cars[] cars = {car1, car2, car3};
        String carsString = Arrays.toString(cars);
        System.out.println("massiv cars: " +carsString);

    }
}