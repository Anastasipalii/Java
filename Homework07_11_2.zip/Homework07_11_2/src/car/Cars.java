package car;

public class Cars {
    private String brand;
    private String model;
    private int year;
    private  double engineCapacity;
    private boolean launched;

    public Cars(String brand, String model, int year, double engineCapacity, boolean launched) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.engineCapacity = engineCapacity;
        this.launched = launched;
    }
    @Override
    public String toString() {
        return "Car{" +
                "brand=' " + brand + '\'' + ", model='" + model +
                '\'' + ", year=" + year + ", engineCapacity=" + engineCapacity +
                ", launched=" + launched + '}';
    }
}
