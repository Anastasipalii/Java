package car;

public enum CarModel {
    BMW,
    TOYOTA,
    AUDI
}
