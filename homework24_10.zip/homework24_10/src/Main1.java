class Calculator {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        int result1 = calculator.multiply(2, 3);
        System.out.println(" The result of multiplying two numbers: " + result1);
        int result2 = calculator.multiply(2, 3, 4);
        System.out.println(" The result of multiplying three numbers: " + result2);
        int result3 = calculator.multiply(2, 3, 4, 5);
        System.out.println(" The result of multiplying four numbers: " + result3);
    }
    private int multiply(int a, int b){
        return a * b;
    }
    private int multiply(int a, int b, int c){
        return multiply(multiply(a, b), c);
    }
    private int multiply(int a, int b, int c, int d){
        return multiply(multiply(a, b), multiply(c, d));
    }
}
