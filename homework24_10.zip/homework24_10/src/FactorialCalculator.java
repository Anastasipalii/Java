import java.util.Scanner;
public class FactorialCalculator {
    private static long factorial(int n) {
        if (n == 0 || n == 1) {
        } else {
            return n * factorial(n - 1);
        }
        return 0;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Vvedite chislo dlya vicheslenia factoriala: ");
        int number = scanner.nextInt();
        if (number < 0) {
            System.out.println("Factorial otrizatelnogo chisla ne opredelen.");
        } else {
            long result = factorial(number);
            System.out.println("Factorial chisla " + number + "raven: " + result);
        }
        scanner.close();
    }

    }

