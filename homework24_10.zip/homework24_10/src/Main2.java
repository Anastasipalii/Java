import java.util.Arrays;
import java.util.Random;
public class Main2 {
    public static void main(String[] args) {
        int[] numbers = new int[8];
        Random random = new Random();
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(500) + 1;
        }
        System.out.println("Source array: " + Arrays.toString(numbers));
        for (int i = 1; i < numbers.length; i+= 2) {
            numbers[i] = 0;
        }
        System.out.println("Array after replacement: " + Arrays.toString(numbers));
        Arrays.sort(numbers);
        System.out.println("Sorted array: " + Arrays.toString(numbers));

    }
}
