import java.util.Arrays;

public class Main3 {
    public static void main(String[] args) {
        String[] strings = {"Mercury" , "Gemini" , "Apollo" , "Skylab", "Skylab B"};
        String maxLengthString = strings[0];
        for (String string : strings) {
            if (string.length() > maxLengthString.length()) {
                maxLengthString = string;
            }
        }
        String minLengthString = strings[0];
        for (String string : strings) {
            if (string.length() < minLengthString.length()) {
                minLengthString = string;
            }
        }
        System.out.println("massiv: " +Arrays.toString(strings));
        System.out.println("Longest string: " + maxLengthString);
        System.out.println("Shortest string: " + minLengthString);
    }
}
