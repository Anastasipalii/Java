import java.time.LocalDate;
import java.util.Arrays;
public class Main {
    public static void main(String[] args) {
        LocalDate[] dates = {
                LocalDate.of(2023, 10, 1),
                LocalDate.of(2023, 7, 15),
                LocalDate.of(2023, 5, 30),
                LocalDate.of(2023, 12, 5),
                LocalDate.of(2023, 3, 22),
                LocalDate.of(2023, 9, 10),
                LocalDate.of(2023, 1, 8),
                LocalDate.of(2023, 11, 18),
        };
        System.out.println("Isshodnyi massiv:");
        System.out.println(Arrays.toString(dates));
        Arrays.sort(dates, (date1, date2) -> date1.getDayOfMonth() - date2.getDayOfMonth());
        System.out.println("Otsortirovanniy massiv po dnu mesaca: ");
        System.out.println(Arrays.toString(dates));

    }
}