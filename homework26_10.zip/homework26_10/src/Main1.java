public class Main1 {
    public static void main(String[] args) {
        int rows = 6;
        int colums = 5;
        char[][] russianAlphabet = new char[rows][colums];
        char letter = 'А';
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < colums; j++) {
                russianAlphabet[i][j] = letter;
                letter++;
                if (letter == 'Е') {
                    letter = 'Ж';
                }

            }

        }
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < colums; j++) {
                System.out.println(russianAlphabet [i][j] + "");
            }
            System.out.println();
            
        }

    }
}
