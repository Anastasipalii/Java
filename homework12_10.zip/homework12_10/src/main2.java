import java.util.Random;
import java.util.Scanner;

public class main2 {
    public static void main(String[] args) {
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        int number1 = random.nextInt(9) + 1;
        int number2 = random.nextInt(9) + 1;
        System.out.println("How much will " + number1 + "multiply one " +
                number2 + "?");
        int userAnswer = scanner.nextInt();
        int correctAnswer = number1 * number2;
        if (userAnswer == correctAnswer) {
            System.out.println("Correct ! ");
        }else {
            System.out.println("Wrong. Correct answer: " + correctAnswer);
        }
    }
}
