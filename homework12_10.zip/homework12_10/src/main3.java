import java.util.Scanner;

public class main3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the year: ");
        int year = scanner.nextInt();
        if (year < 1935) {
            System.out.println("Elvis has not yet given birth");
        }else if (year <= 1977) {
            System.out.println("Elvis is alive! ");
        }else {
            System.out.println("Elvis is forever in our hearts! ");
        }
    }
}
