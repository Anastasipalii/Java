import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the first number: ");
        double m = scanner.nextDouble();
        System.out.println("Enter the second number: ");
        double n = scanner.nextDouble();
        double closerNumber = (Math.abs(10 - m) < Math.abs(10 - n )) ? m:n;
        System.out.println("Numer " + closerNumber + "closer to 10.");

    }
}