import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the length in meters: ");
        double meters = scanner.nextDouble();
        double kilometers = meters / 1000;
        double miles = meters * 0.000621371;
        double feet = meters * 3.28084;
        double arshins = meters * 1.40607424;
        System.out.println("Length in kilometers: " + kilometers + "km");
        System.out.println("Length in miles: " + miles + "mile");
        System.out.println("Length in feet: " + feet + "feet");
        System.out.println("Length in arshins: " + arshins + "arshins");

    }
}