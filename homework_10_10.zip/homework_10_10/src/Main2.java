import java.util.Scanner;

public class Main2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("The amount cost of purchases (in rubles and coins) : ");
        double totalAmount = scanner.nextDouble();
        System.out.println("The amount of money given by the buyer (in rubles and coins) :");
        double paidAmount = scanner.nextDouble();
        double change = paidAmount - totalAmount ;
        int rubles = (int) change ;
        int coins = (int) ((change - rubles) * 100);
        System.out.println("Rest: " + rubles + "rubles" + coins + "coins");

        }
    }

