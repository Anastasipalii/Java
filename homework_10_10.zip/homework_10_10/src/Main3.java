public class Main3 {
    public static void main(String[] args) {
        boolean isYearFinished = true;
        boolean isGoodWeather = true;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = true;
        boolean hasKateComeBack = true;
        boolean willGoOnTrip = (isYearFinished && isGoodWeather && (hasBoughtRaincoats
        || (isJimFree ^ hasKateComeBack )));
        System.out.println("The hike will take place: " + willGoOnTrip);
    }
}
