import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите первое целое число: ");
        int число1 = scanner.nextInt();
        System.out.println("Введите второе целое число: ");
        int число2 = scanner.nextInt();
        int сумма = число1 + число2;
        System.out.println("Сумма: " + сумма);
        int разница = число1 - число2;
        System.out.println("Разница: " + разница);
        int произведение = число1 * число2;
        System.out.println("Произвидение: " + произведение);
        if (число2 != 0) {
            double частное = (double) число1 / число2;
            System.out.println("Частное: " + частное);
        } else  {
            System.out.println("Деление на ноль невозможно.");
        }

    }
}