package math;

public class MathUtility {
    private MathUtility() {
    }
    public static double addAll(double...numbers) {
        double sum = 0;
        for (double num : numbers) {
            sum += num;
        }
        return sum;
    }
    public static double minusAll (double base, double... numbers) {
        for (double num : numbers) {
            base -= num;
        }
        return base;
    }
    public static double multAll(double... numbers) {
        double result = 1;
        for (double num : numbers) {
            result *= num;
        }
        return result;
    }
    public static double powAll(double base, double... powers) {
        for (double power : powers) {
            base = Math.pow(base, power);
        }
        return base;
    }
}
