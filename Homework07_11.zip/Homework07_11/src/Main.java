import math.MathUtility;

public class Main {
    public static void main(String[] args) {
        double sum = MathUtility.addAll(1, 2, 3, 4, 5);
        System.out.println("Summa chisel: " + sum);
        double difference = MathUtility.minusAll(20, 5, 3, 2);
        System.out.println("Raznost chisel: " + difference);
        double product = MathUtility.multAll(2, 3, 4);
        System.out.println("Proizvidenie chisel: " + product);
        double powerResult = MathUtility.powAll(2, 3, 2);
        System.out.println("Resultat vosvedenia v stepen: " + powerResult);
    }
}