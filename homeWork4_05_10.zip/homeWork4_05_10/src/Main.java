public class Main {
    public static void main(String[] args) {
        double a = Math.random();
        double b = Math.random();
        System.out.println("Первое число (a): " +a);
        System.out.println("Второе число (b): " +b);
        double разницаПоМодулю = Math.abs(a - b);
        System.out.println("Разница чисел по модулю: " + разницаПоМодулю);
        double минимальное = Math.min(a,b);
        System.out.println("Минимальное число: " + минимальное);
        double максимальное = Math.max(a,b);
        System.out.println("Максимально число: " + максимальное);
        double степень = Math.max(a, b * 10);
        System.out.println("Полученное число после возведения в степень: " + степень);
    }
}