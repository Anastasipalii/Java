import object.Student;
import object.University;

public class Main {
    public static void main(String[] args) {
        University university = new University();
        Student student1 = university.createStudent("Anastasiia" ,"19973" , 26);
        Student student2 = new Student(student1);
        System.out.println(student1 == student2);
        student2.setAge(23);
        System.out.println(student1.getAge());
    }
}