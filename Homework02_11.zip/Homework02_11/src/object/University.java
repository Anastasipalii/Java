package object;

public class University {
    public Student createStudent(String name, String rollNumber, int age) {
        return new Student(name, rollNumber, age);
    }
}
