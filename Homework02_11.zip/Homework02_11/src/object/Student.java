package object;

public class Student {
    public String name;
    String rollNumber;
    private int age;

    public Student(String name, String rollNumber, int age) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.age = age;
    }

    public Student(String name, String rollNumber) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.age = 0;
    }
    public int getAge(){
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public Student (Student original) {
        this.name = original.name;
        this.rollNumber = original.rollNumber;
        this.age = original.age;
    }
}
