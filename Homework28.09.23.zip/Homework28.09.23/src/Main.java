public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        byte b = 4;
        short s = 56;
        int i = 89;
        long l = 12121;
        float f = 4.7333436F;
        double d = 4.355453532;
        char c = 'G';
        boolean bool = true;
        System.out.println(b);
        System.out.println(s);
        System.out.println(i);
        System.out.println(l);
        System.out.println(f);
        System.out.println(d);
        System.out.println(c);

        System.out.print("345:");
        int number = 345;
        int digit1 = number / 100;
        int digit2 = number % 100 / 10;
        int digit3 = number % 10;
        System.out.println("345" + "number" + ">" + digit1 + "," + digit2 + "," + digit3);

        System.out.print("987:");
        number = 987;
        int digit4 = number / 100;
        int digit5 = number % 100 / 10;
        int digit6 = number % 10;
        System.out.println("987" + "number" + "->" + digit4 + "," + digit5 + "," + digit6);

    }
}


