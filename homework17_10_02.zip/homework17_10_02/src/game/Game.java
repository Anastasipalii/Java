package game;

public enum Game {
    STONE,
    SCISSORS,
    PAPER
}
