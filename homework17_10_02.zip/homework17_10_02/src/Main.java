import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String [] choices = {"Stone", "Scissors", "Paper"};
        Random random = new Random();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select: 1 - Stone, 2 - Scissors, 3 - Paper");
        int userChoice = scanner.nextInt() - 1 ;
        int computerChoice = random.nextInt(3);
        System.out.println("Your choice: " + choices [userChoice]);
        System.out.println("Computr choice: " + choices [computerChoice]);
        if (userChoice == computerChoice) {
            System.out.println("Draw!");
        } else if ((userChoice == 0 && computerChoice == 1) ||
                (userChoice == 1 && computerChoice == 2) ||
                (userChoice == 2 && computerChoice == 0)) {
            System.out.println("You won!");
        } else {
            System.out.println("The computer won!");
        }

    }
}