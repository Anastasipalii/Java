import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите ваше имя: ");
        String имя = scanner.nextLine();
        System.out.println("Введите ваш возраст (полных лет): ");
        int возраст = scanner.nextInt();
        System.out.println("Введите ваш вес (в килограммах): ");
        double вес = scanner.nextDouble();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %.2f"  +
                "килограмм золота.", имя, возраст, вес);
    }
}