import java.util.Scanner;

public class Main1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String userInput;
        do {
            System.out.println("Enter start of range (integer):");
            int start = scanner.nextInt();
            System.out.println("Enter end of range (integer):");
            int end = scanner.nextInt();
            int sum = 0;
            for (int i = start; i <= end ; i++) {
                if (i % 2 != 0) {
                    sum += i;
                }
            }
            System.out.println("The sum of all non integers in the range from " +
                    start + "to" + end + "equal to: " + sum);
            System.out.println("Type 'quit' to end the programm , or any other " +
                    "text to continue: ");
            scanner.nextLine();
            userInput = scanner.nextLine();
        } while (! userInput.equals("quit"));
        System.out.println("The program is complete.");
    }
}
