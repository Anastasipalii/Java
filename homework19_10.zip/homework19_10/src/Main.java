import java.util.Random;

public class Main {
    public static void main(String[] args) {
        int targetAmount = 10000;
        int collectedAmount = 0;
        Random random = new Random();
        while (collectedAmount < targetAmount) {
            int friendContribution = random.nextInt(451) + 50;
            collectedAmount += friendContribution;
            System.out.println("A friend gave " + friendContribution + "dollars. ");
        }
        System.out.println("Hooray! Enough funds have been raised for a new computer" +
                collectedAmount + "dollars. ");
        System.out.println("Time to celebrate! Let's go to the best bar in town! ");
    }
}