import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        byte byteVariable = (byte) random.nextInt();
        short shortVariable = (short) random.nextInt();
        int intVariable = random.nextInt();
        long longVariable = random.nextLong();
        float floatVariable = random.nextFloat();
        double doubleVariable = random.nextDouble();
        char charVariable = (char) (random.nextInt(26) + 'a');
        boolean booleanVariable = random.nextBoolean();

        System.out.println("byte: " + byteVariable);
        System.out.println("short: " + shortVariable);
        System.out.println("int: " + intVariable);
        System.out.println("long: " + longVariable);
        System.out.println("float: " + floatVariable);
        System.out.println("double: " + doubleVariable);
        System.out.println("char: " + charVariable);
        System.out.println("boolean: " + booleanVariable);

        String stringVariable = String.valueOf(random.nextInt());
        System.out.println("String: " + stringVariable);


        Scanner scanner = new Scanner(System.in);
        System.out.print("Анастасия :");
        String имя = scanner.nextLine();
        System.out.print("26 (полных лет): ");
        int возраст = scanner.nextInt();
        System.out.print("49 (в килограммах): ");
        double вес = scanner.nextDouble();
        System.out.printf("Уважаемый, %s! В свои %d лет Вы для нас дороги, как %.2f " +
                "килограмм золота.", имя, возраст, вес);



    }
}